 require([
     'jquery',
     'splunkjs/mvc',
     'splunkjs/mvc/simplexml/ready!'], function($, mvc,) {
     var submittedTokens = mvc.Components.get('submitted');
     // Listen for a change to the token tokHTML value
     submittedTokens.on("change:search1", function(model, search1, options) {
         var tokHTMLJS=submittedTokens.get("search1");
         if (tokHTMLJS!==undefined)
         {
             tokHTMLJS = highlight(tokHTMLJS);
             $("#search1htmlPanel").html("Goodbye");
         }
     });
     
          submittedTokens.on("change:search2", function(model, search2, options) {
         var tokHTMLJS=submittedTokens.get("search2");
         if (tokHTMLJS!==undefined)
         {
             tokHTMLJS= "<h1>" + tokHTMLJS.replace(/\|\s/gi,"<br/>| ") + "</h1>" ;
             $("#search2htmlPanel").html(tokHTMLJS);
             tokHTMLJS = highlight(tokHTMLJS);
             $("#search2htmlPanel").html(tokHTMLJS);
         }
     });
 });

function highlight(tokHTMLJS) {
         if (tokHTMLJS!==undefined)
         {
             
             tokHTMLJS= tokHTMLJS.replace(/\./gi, function (x){
                 x= "<img src=\"/static/app/battleship/W.png\"/>" ;
                 return x ;
             } ) ;

         }
  return null;
}