 require([
     'jquery',
     'splunkjs/mvc',
     'splunkjs/mvc/simplexml/ready!'], function($, mvc,) {
     var submittedTokens = mvc.Components.get('submitted');
     // Listen for a change to the token tokHTML value
     submittedTokens.on("change:search1", function(model, search1, options) {
         var tokHTMLJS=submittedTokens.get("search1");
         if (tokHTMLJS!==undefined)
         {
             tokHTMLJS = highlight(tokHTMLJS);
             $("#search1htmlPanel").html(tokHTMLJS);
         }
     });
     
          submittedTokens.on("change:search2", function(model, search2, options) {
         var tokHTMLJS=submittedTokens.get("search2");
         if (tokHTMLJS!==undefined)
         {
             tokHTMLJS = highlight(tokHTMLJS);
             $("#search2htmlPanel").html(tokHTMLJS);
         }
     });
 });

function highlight(tokHTMLJS) {
         if (tokHTMLJS!==undefined)
         {
             
             tokHTMLJS= tokHTMLJS.replace(/\./g, function (x){
                 x= "<img src=\"/static/app/battleship/W.png\"/>" ;
                 return x ;
             } ) ;
             
             tokHTMLJS= tokHTMLJS.replace(/C/g, function (x){
                 x= "<img src=\"/static/app/battleship/C.png\"/>" ;
                 return x ;
             } ) ;

             tokHTMLJS= tokHTMLJS.replace(/S/g, function (x){
                 x= "<img src=\"/static/app/battleship/S.png\"/>" ;
                 return x ;
             } ) ;

             tokHTMLJS= tokHTMLJS.replace(/D/g, function (x){
                 x= "<img src=\"/static/app/battleship/D.png\"/>" ;
                 return x ;
             } ) ;
             
             tokHTMLJS= tokHTMLJS.replace(/B/g, function (x){
                 x= "<img src=\"/static/app/battleship/B.png\"/>" ;
                 return x ;
             } ) ;
             
             tokHTMLJS= tokHTMLJS.replace(/A/g, function (x){
                 x= "<img src=\"/static/app/battleship/A.png\"/>" ;
                 return x ;
             } ) ;
             
            tokHTMLJS= tokHTMLJS.replace(/E/g, function (x){
                 x= "<img src=\"/static/app/battleship/E.png\"/>" ;
                 return x ;
             } ) ;
             
            tokHTMLJS= tokHTMLJS.replace(/M/g, function (x){
                 x= "<img src=\"/static/app/battleship/M.png\"/>" ;
                 return x ;
             } ) ;
             
             tokHTMLJS= tokHTMLJS.replace(/\|\|\|/g, function (x){
                 x= "<br/>" ;
                 return x ;
             } ) ;
             return tokHTMLJS;
         }
  return null;
}
